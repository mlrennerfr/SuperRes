function correctdetections

% dialog box to enter recognition criteria for images
prompt = {'Max. distance for multiple detections (nm):','Maximum blinking period (frames):'};
num_lines= 1;
dlg_title = 'Correction of multiple detections';
def = {'20','10'};
answer  = inputdlg(prompt,dlg_title,num_lines,def);
exit=size(answer);
if exit(1) == 0;
    return;
end
dist=str2num(answer{1});
dist=str2num(answer{2});
maxblink=str2num(answer{3});

%files
d=dir('*.mat*'); % .stk files
st={d.name};
if isempty(st)==1
    msgbox(['No files!!'],'','error');
    return
end

%choose data
[listafiles,v] = listdlg('PromptString','Select files:','SelectionMode','multiple','ListString',st);
if v==0
     return
end



for nromovie=1:size(listafiles,2)
    matfile=st{listafiles(nromovie)} 
   disp=['Correction of multiple detections: File ',matfile];
   disp(' ');
    [filename,rem]=strtok(matfile,'.');
    correctedfile=[filename,'-corr.mat']  
    
   % aux=correctdetections2(matfile,dist,minintens);
    aux=correctdetections4(matfile,dist,maxblink);
    
    corrpeak=aux(find(isnan(aux(:,2))==0),:);
    clear aux   
    
    % save new data
    if isempty(corrpeak)==0
        matrice_results(1,:)=corrpeak(:,1);
        matrice_results(2,:)=corrpeak(:,3);
        matrice_results(3,:)=corrpeak(:,2);
        matrice_results(4,:)=corrpeak(:,4);
        matrice_results(5,:)=corrpeak(:,5);
        savename=[filename, '-corr.mat'];
        save(savename, 'matrice_results'); % 
        clear matrice_results
    end
end %loop

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

