function [fr,x,y,alpha,radius, radiusmean,sigma, blink, sommevalid, ratio,z,test1,test2] = detectionMTTSR3D(name_stk , stack, Nb_image_ds_stack, seuil_detec_1vue, wn,...
    r0, nb_defl, seuil_alpha, activation_sig_fit,fitresult,szpx)
%function [fr,x,y,alpha,radius, radiusmean,sommevalid] = detectionMTTSR(name_stk , stack, Nb_image_ds_stack, seuil_detec_1vue, wn,...
%    r0, nb_defl, seuil_alpha, activation_sig_fit)
%
% Detection from MTT programs, modified to include 3D detection
% Adapted for SuperRes (2016), and SuperRes_v2 (2020)
% adapted to read large .tiff files
%
% Marianne Renner fev 2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pfa=seuil_detec_1vue;
n_deflt=nb_defl;
demi_wn = ceil(wn/2);
x=[];
y=[];
alpha=[];
fr=[];
radius=[];
ratio=[];
z=[];
test1=[];
test2=[];
sigma=[];
blink=[];


auxx=[];
auxy=[];
auxalpha=[];
auxfr=[];
auxradius=[];
sommevalid=0;
matrice_results=[];

waitbarhandle=waitbar( 0,'Please wait...','Name',['Peak detection in ',name_stk]) ;

totpoints=0;

for ind=1:Nb_image_ds_stack
   
    if exist('waitbarhandle')
       waitbar(ind/Nb_image_ds_stack,waitbarhandle,['Frame # ',num2str(ind)]);
    end
    
    
    if isempty(stack)==0
        input = stack{ind, 1};
        input=double(input);
    else
        input = imread_big(name_stk,ind);
        input = double(input);
    end

    [idim, jdim] = size(input) ;
    
    
    [lest,ldec,dfin] = detect_et_estime_part_1vue (input, wn, r0, pfa, activation_sig_fit) ;
    input_deflt = deflat_part_est(input, lest, wn);
    lestime1 = lest;
    if n_deflt==0
        lestime= lestime1;
    else
        for n=1:n_deflt
            [l,ld,d,N] = detect_et_estime_part_1vue (input_deflt, wn, r0, pfa, activation_sig_fit) ;
            lestime = [lestime1 ; l];
            dfin = dfin | d ;
            input_deflt = deflat_part_est(input_deflt, l, wn);
        end%for
    end
    test_all = lestime(:,7) & (lestime(:,4)>seuil_alpha) & ...
        (lestime(:,2)>demi_wn) & (lestime(:,2)<idim-demi_wn) & ...
        (lestime(:,3)>demi_wn) & (lestime(:,3)<jdim-demi_wn) ;

    [ind_valid, tmp] = find(test_all);
    
    if isempty(ind_valid)
        tab_param = NaN(8, 8) ;
        tab_var = NaN(8, 8) ;
   else
        nb_valid = max(size(ind_valid));
        sommevalid=sommevalid + nb_valid;
        %==========================================================================
        %% on alloue les tableaux de sorties
        tab_param = zeros(nb_valid, 8) ;
        tab_var = zeros(nb_valid, 8) ;
        %==========================================================================
        %% on initialise les tableaux de sorties
        tab_param(:,1) = (1:nb_valid)' ;
        tab_param(:,2:8) = [ind.*ones(nb_valid,1), ...
            lestime(ind_valid,[2,3,4,6]), ... %% i j alpha rayon
            lestime(ind_valid,5), ... %sig2_b
            Nb_image_ds_stack*ones(nb_valid,1)];

        %% valeurs initiales (par default)
        %% dans calcul_reference(traj, t, param, T)
        tab_var(:,1)   = (1:nb_valid)' ;
        tab_var(:,2:8) = [ones(nb_valid,1), ...
            zeros(nb_valid,4), ...
            lestime(ind_valid,5), ...  %% sig2_b
            Nb_image_ds_stack*ones(nb_valid,1) ];
        tab_moy = tab_var ;

        %==========================================================================
        param((1:nb_valid),1)=tab_param((1:nb_valid),1);
        param((1:nb_valid),(2:8))=tab_param((1:nb_valid),2:8);
        var((1:nb_valid),1)=tab_var((1:nb_valid),1);
        var((1:nb_valid),(2:8))=tab_var((1:nb_valid),2:8);
        moy((1:nb_valid),1)=tab_moy((1:nb_valid),1);
        moy((1:nb_valid),(2:8))=tab_moy((1:nb_valid),2:8);

        Structure(ind)=struct('param', {param}, 'var', {var}, 'moy', {moy});
        %==========================================================================

       % x=[x, Structure(ind).param(:,3)'];
       % y=[y, Structure(ind).param(:,4)'];
       % alpha=[alpha, Structure(ind).param(:,5)'];
       % fr=[fr, Structure(ind).param(:,2)'];
       % radius=[radius, Structure(ind).param(:,6)'];
       % sigma2=[radius, Structure(ind).param(:,7)'];
       % blink2=[radius, Structure(ind).param(:,8)'];
        
        auxx=Structure(ind).param(:,3);
        auxy=Structure(ind).param(:,4);
        auxalpha=Structure(ind).param(:,5);
        auxfr=Structure(ind).param(:,2);
        auxradius=Structure(ind).param(:,6);
        auxsigma2=Structure(ind).param(:,7);
        auxblink2=Structure(ind).param(:,8);
                
        controllength=size(auxx,1);
        auxsigma=auxsigma2(1:controllength);
        auxblink=auxblink2(1:controllength);
        auxratio=[];
        auxz=[];
        auxtest1=[];
        auxtest2=[];
        
        totpoints=totpoints+controllength;
        
        for i=1:size(auxx,1);
                widthy=0; widthx=0;
                posx=fix(auxx(i));  posy=fix(auxy(i));
                
                % fit gaussian 2D ellipse
                gsize = fix(wn/2)*2+1;
                gs2= fix(gsize/2);
                xsize= auxradius(i);  ysize=auxradius(i);
                xfits=fix(max(1,posx-gs2)); xfite=fix(min(size(input,2),posx+gs2));
                yfits=fix(max(1,posy-gs2)); yfite=fix(min(size(input,1),posy+gs2));
                xsz=xfite-xfits+1; ysz=yfite-yfits+1;
                fisize = xsz*ysz;
                X0=posx-xfits+1; Y0=posy-yfits+1;
                gXstart=max(gs2+2-X0,1); gXend=min(gs2+1-X0+xsz,gsize);
                gYstart=max(gs2+2-Y0,1); gYend=min(gs2+1-Y0+ysz,gsize);
                fimage = input(yfits:yfite,xfits:xfite);  
                maxvalint=max(max(fimage(:)));
                
                % pre allocate
                auxratio(i)=1000 ; 
                auxz(i)=1000; 
                auxtest1(i)=0;
                auxtest2(i)=0;

                if maxvalint>seuil_alpha
                    fpar = [X0,Y0,0, max(max(fimage(:))), min(min(fimage(:))), xsize, ysize];
                    
                    [p, fval,exitflag,sse] = fitcurvegauss2D(fpar, fimage);
                    
                    if exitflag ==0 % not converged to solution
                    else
                        %tests
                        [testa]=testpeaks3D(fimage,p,fval);
                        auxtest1(i)=testa(1);
                        auxtest2(i)=testa(2);
                        widthx=p(7); % attention: transposed
                        widthy=p(6);
                        if widthx>0 && widthy>0
                            auxratio(i)=widthx/widthy;
                            auxz(i)= (auxratio(i)-fitresult(2,4))/fitresult(1,4);
                            if auxz(i)==0
                                auxz(i)=auxz(i) /szpx; %szpx in nm, pkdata in px
                            end
                        else
                             auxratio(i)=Inf;
                              auxz(i)=Inf; 
                        end
                    end
                end % min intens
                
            end % all detection data
            
            x=[x;auxx];
            y=[y;auxy];
            alpha=[alpha;auxalpha];
            fr=[fr;auxfr];
            radius=[radius;auxradius];
            sigma=[sigma;auxsigma];
            blink=[blink;auxblink];
            ratio=[ratio;auxratio'];
            z=[z;auxz'];
            test1=[test1;auxtest1'];
            test2=[test2;auxtest2'];

            clear param var moy tab_var tab_moy tab_param
    end
    
    
    
    
end

radiusmean = median(radius);

disp(totpoints)


close(waitbarhandle);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



