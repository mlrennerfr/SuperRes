function [datawidth,totalpk]=go3D(pk,Image,totframes,fitresult,wn,minvalint,szpx,waitbarhandle)
%function pk=go3D(pk,Image,ImagePar,curve,wn)
   % function pk=go3D(pk,Image,ImagePar,curve,wn,szpx)

%pk: pk file, VOIR STRUCTURE
%Image,ImagePar : movie for fitting
%curve: calibration curve
datawidth=[];
totalpk=[];

disp(Image)
    
for i=1:totframes;
        datamatrix=Image(i).data;
        datamatrix=double(datamatrix);
        pkdata=pk(find(pk(:,1)==i),:);
        if exist('waitbarhandle')
            waitbar(i/totframes,waitbarhandle,['Frame # ',num2str(i)]);
        end

        if isempty(pkdata)==0
            for i=1:size(pkdata,1);
                widthy=0; widthx=0;
                posx=fix(pkdata(i,2));  posy=fix(pkdata(i,3));
                % fit gaussian 2D ellipse
                
                gsize = fix(wn/2)*2+1;
                gs2= fix(gsize/2);
                xsize= pkdata(i,4);  ysize=pkdata(i,4);
                xfits=fix(max(1,posx-gs2)); xfite=fix(min(size(datamatrix,2),posx+gs2));
                yfits=fix(max(1,posy-gs2)); yfite=fix(min(size(datamatrix,1),posy+gs2));
                xsz=xfite-xfits+1; ysz=yfite-yfits+1;
                fisize = xsz*ysz;
                X0=posx-xfits+1; Y0=posy-yfits+1;
                gXstart=max(gs2+2-X0,1); gXend=min(gs2+1-X0+xsz,gsize);
                gYstart=max(gs2+2-Y0,1); gYend=min(gs2+1-Y0+ysz,gsize);
                fimage = datamatrix(yfits:yfite,xfits:xfite);  
                maxvalint=max(max(fimage(:)));
                
                if maxvalint>minvalint
                    fpar = [X0,Y0,0, max(max(fimage(:))), min(min(fimage(:))), xsize, ysize];
                    
                    [p, fval,exitflag,sse] = fitcurvegauss2D(fpar, fimage);
                    
                    % VOIR!!!!!!!!!!!!!!!!!!!!!!
                    if exitflag ==0 % not converged to solution
                        pkdata(i,8)=1000 ;                    
                        pkdata(i,9)=1000; 
                        [tests]=[ 0 0];
                    else
                        
                        %tests
                        [tests]=testpeaks3D(fimage,p,fval);
                        widthx=p(7); % attention: transposed
                        widthy=p(6);
                        if widthx>0 && widthy>0
                            ratio=widthx/widthy;
                        end
                        pkdata(i,8)=ratio ;
                        % calculate z
                       % z=interp1(curve(:,1), curve(:,2), ratio);
                       
                      % z=feval(fitresult,ratio);
                      % z=fitresult(1,4)*ratio+fitresult(2,4);
                      
                       z= (ratio-fitresult(2,4))/fitresult(1,4);
                          %a: fitresult(1,4) b: fitresult(2,4)

                       
                        if z==0
                            pkdata(i,9)=0;
                        else
                           % pkdata(i,17)=z / (szpx/1000);
                            %pkdata(i,9)=z / (szpx/1000);
                            pkdata(i,9)=z /szpx; %szpx in nm, pkdata in px
                        end
                        datawidth=[datawidth; pkdata(i,1:4) widthx widthy pkdata(i,8)];
                    end
                    
                    pkdata(i,10)=tests(1);
                    pkdata(i,11)=tests(2);
                    totalpk=[totalpk; pkdata(i,:)]; 
                end % min intens
            end % pkdata
            clear pkdata
        end % empty pkdata
end % frames



