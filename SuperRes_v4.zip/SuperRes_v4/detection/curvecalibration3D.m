function varargout = curvecalibration3D(varargin)
%CURVECALIBRATION3D M-file for curvecalibration3D.fig
% Last Modified by GUIDE v2.5 02-Mar-2011 19:20:17

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @curvecalibration3D_OpeningFcn, ...
                   'gui_OutputFcn',  @curvecalibration3D_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
%-------------------------------------------------------------------------
% --- Executes just before curvecalibration3D is made visible.
function curvecalibration3D_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
handles.valfactor=0.1;
axes(handles.axes1);
%(handles.factor,'value',0); %frame #1

guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = curvecalibration3D_OutputFcn(hObject, eventdata, handles,detoptions)
varargout{1} = handles.output;

guidata(hObject,handles) ;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in detect.
function detect_Callback(hObject, eventdata, handles)

% options: initialization
%set(handles.factor,'value',0.1);
showdetection(handles);
guidata(gcbo,handles) ;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in accept.
function accept_Callback(hObject, eventdata, handles,detoptions)

% detection x,y,z values over all images
datamatrix=[];
detoptions=get(handles.output,'userdata');
st=get(handles.loadfile,'userdata')  %files
file=st;
[namefile,rem]=strtok(file,'.');
 
lastframe=get(handles.text8,'value');
Image=detoptions.image;
ImagePar=detoptions.imagepar;
YDim=ImagePar.y;
XDim=ImagePar.x;
% movie: actual frame
pktotal=[];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in loop.
function loop_Callback(hObject, eventdata, handles)
% loops between ini and end images, detects peaks, finds widths, tracks...

% options: initialization
%set(handles.factor,'value',0.1);
firstimage=str2num(get(handles.firstframe,'string'));
lastimage=str2num(get(handles.finalframe,'string'));
deltaz=str2num(get(handles.deltaz,'string'));
detoptions=get(handles.output,'userdata');
ecartframes=round(lastimage-firstimage)/2;
%[options,cutoffs]=readdetectionoptions; 
[options]=readdetectionoptions;

ImagePar=detoptions.imagepar;
Ydim=ImagePar.y;
Xdim=ImagePar.x;
resultcurve=[];
count=1;
frame=1;

%pkdata=[];
results3Dallpeak=[];

for frame=firstimage:lastimage
    set(handles.loop,'value',frame); % actualframe
    disp(['Frame ',num2str(frame)])
    results3Dpeak=[]; totalpk=[];
    [totalpk,results3Dpeak]=showdetection(handles);
    %pkdata=[pkdata; totalpk];
    results3Dallpeak=[results3Dallpeak; results3Dpeak];
    %resultcurve(count,1)=frame;
    %count=count+1;
end

% tracking
%[trc]=connectpeaks(pkdata,0.05,Xdim,Ydim,options);
%reconnection

vectorcurve=[];

file=get(handles.filename,'string');
[namefile,rem]=strtok(file,'.');

if isempty(results3Dallpeak)==0
    
    save([namefile,'-results3D.txt'],'results3Dallpeak','-ascii');

    for i=1:max(results3Dallpeak(:,1)) %all frames
        indexframe=find(results3Dallpeak(:,1)==i);
        if isempty(indexframe)==0
            meanwidth=mean(results3Dallpeak(indexframe,8)); 
            SDwidth=std(results3Dallpeak(indexframe,8)); 
            vectorcurve=[vectorcurve; (i-firstimage-ecartframes)*deltaz meanwidth SDwidth];
        end
    end
    
    [a,b,sqrtChi2sNm2,corr]=linearegresion(vectorcurve(:,1),vectorcurve(:,2));

    stop=0;
    index2=[1:size(vectorcurve,1)];
    while ~stop
        
        figure
        plot(vectorcurve(index2,1),vectorcurve(index2,2)-b+1,'-b') %ratio=1 => z=0
        hold on
        plot(vectorcurve(index2,1),vectorcurve(index2,1)*a+1,'-r') %ratio=1 => z=0
        hold off
        
        % accept?
        button = questdlg('Accept ?','','Yes','No','Yes');
        stop = strcmp(button,'Yes');
        
        if stop==1
            break
        end
        
        %select range (or not)
        prompt = {'z range to keep:'};
        num_lines= 1;
        dlg_title = '3D calibration curve';
        minval=num2str(min(vectorcurve(:,1)));
        maxval=num2str(max(vectorcurve(:,1)));
        def = {[minval,' ',maxval]}; % default values
        answer  = inputdlg(prompt,dlg_title,num_lines,def);
        exit=size(answer);
        if exit(1) == 0;
            return; 
        end
        range=str2num(answer{1});     % min max
        
        index1=find(vectorcurve(:,1)>range(1))-1;
        index2=find(vectorcurve(index1,1)<range(2))+1;
        
        % linear fit mean curve
        [a,b,sqrtChi2sNm2,corr]=linearegresion(vectorcurve(index2,1),vectorcurve(index2,2));
        
        % resultcurve(:,1:3)=vectorcurve(:,:);
        clear resultcurve
        resultcurve(:,1:3)=vectorcurve(index2,:);
        resultcurve(1,4)=a;
        resultcurve(2,4)=b;
        resultcurve(3,4)=sqrtChi2sNm2;
        resultcurve(4,4)=corr;
    end %while
    
    save([namefile,'-curvecalib.txt'],'resultcurve','-ascii');

end
   

guidata(gcbo,handles) ;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function showimage(handles,first)

%if nargin<2
%    first=0;
%end

datamatrix=[];
detoptions=get(handles.output,'userdata');
actualframe=get(handles.loop,'value');
lastframe=get(handles.text8,'value');
if actualframe==0
    actualframe=1;
elseif actualframe>lastframe
    actualframe=lastframe;
end
Image=detoptions.image;
ImagePar=detoptions.imagepar;
YDim=ImagePar.y;
XDim=ImagePar.x;

% movie: actual frame
datamatrix=Image(actualframe).data;
datamatrix=double(datamatrix);

%figure;
axes(handles.axes1);
set(handles.text8,'string',['Frame = ',num2str(actualframe),' (of ',num2str(lastframe),')']);
[Xdim,Ydim]=size(datamatrix);
prop=get(handles.text11,'value') ;  %correcion contraste
if prop==0
    prop=0.5;
end
stackmin=(min(min(min(datamatrix))));
stackmax=(max(max(max(datamatrix))));

%if first==1
 %  conval=1;
%   valfactor=round(1000/stackmax*0.5)
%   set(handles.factor,'string',valfactor);
%else
   valfactor=str2num(get(handles.factor,'string'));
   conval=round(prop*(stackmax*valfactor))/1000;
   if conval==0
      conval=0.00001;
   end
%end
datamatrix=datamatrix*conval;

imshow(datamatrix,[stackmin stackmax],'InitialMagnification','fit');

axis([0,Ydim,0,Xdim]);
hold on
%datamatrix=[];
clear datamatrix
guidata(gcbo,handles) ;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [totalpk,results3Dpeak]=showdetection(handles,opt)
% detects with 2D Gaussian; first with one width to detect positions, then
% with two width to detect deformation

if nargin<2
    opt=1;
end
pkdata=[];
results3D=[];
results3Dpeak=[];
totalpk=[];
minvalint=str2num(get(handles.mininten,'string'));

showimage(handles);

detoptions=get(handles.output,'userdata');
Image=detoptions.image;
ImagePar=detoptions.imagepar;
Ydim=ImagePar.y;
Xdim=ImagePar.x;
[options]=readdetectionoptions; 
options(13)=str2num(get(handles.maxinten,'string'));
axes(handles.axes1);
actualframe=get(handles.loop,'value');
lastframe=get(handles.text8,'value');
if actualframe==0
    actualframe=1;
elseif actualframe>lastframe
    actualframe=lastframe;
end
set(handles.text8,'string',['Frame = ',num2str(actualframe),' (of ',num2str(lastframe),')']);
frame=actualframe;


% movie: actual frame
datamatrix=Image(actualframe).data;
datamatrix=double(datamatrix);

%recognize peaks 
result=[];
datapeaks = detecpeak(double(Image(actualframe).data), options);
if size(datapeaks)>0
    datapeaks = [frame * ones(size(datapeaks,1),1),datapeaks];
    result = [result;datapeaks];
end

lista1=[];    
 
if length(result)>0
   pkdata= cleanpk (result, options, 2); % size and intensity
   plot (result(:,2), result(:,3),'o','markeredgecolor',[0 0 1]); 
   hold on;
   if length(pkdata)>0
         plot (pkdata(:,2), pkdata(:,3),'o','markeredgecolor',[1 0 0],'markersize',8);
   end
   result=pkdata;

   for i=1:size(pkdata,1);
      widthy=0;
      widthx=0;
      posx=fix(pkdata(i,2));
      posy=fix(pkdata(i,3));
      %create sub-image for the fit
      gsize = fix(options(8)/2)*2+1;
      gs2= fix(gsize/2);
      xsize= pkdata(i,4);
      ysize=pkdata(i,4);
      xfits=fix(max(1,posx-gs2)); xfite=fix(min(size(datamatrix,2),posx+gs2));
      yfits=fix(max(1,posy-gs2)); yfite=fix(min(size(datamatrix,1),posy+gs2));
      xsz=xfite-xfits+1; ysz=yfite-yfits+1;
      fisize = xsz*ysz;
      X0=posx-xfits+1; Y0=posy-yfits+1;
      gXstart=max(gs2+2-X0,1); gXend=min(gs2+1-X0+xsz,gsize);
      gYstart=max(gs2+2-Y0,1); gYend=min(gs2+1-Y0+ysz,gsize);
      fimage = datamatrix(yfits:yfite,xfits:xfite);
      
      maxvalint=max(max(fimage(:)));
      
      if maxvalint>minvalint
         plot (pkdata(i,2), pkdata(i,3),'o','markeredgecolor',[0 1 0],'markersize',6);
         totalpk=[totalpk; pkdata(i,1:15)];
         % initialization
        % fpar = [X0,Y0,0, pi/4/log(2)*(max(fimage(:))-min(fimage(:)))*gsize^2 , min(fimage(:)), xsize, ysize];
         fpar = [X0,Y0,0, max(max(fimage(:))), min(min(fimage(:))), xsize, ysize];
            p = fitcurvegauss2D(fpar, fimage);
            widthx=p(7); % attention: transposed
            widthy=p(6);
      
            % results
            if widthx>0 & widthy>0
                ratio=widthx/widthy;
                results3Dpeak=[results3Dpeak; actualframe i pkdata(i,2) pkdata(i,3) xsize widthx widthy ratio max(max(fimage(:)))];
            end
            %last columns: to calculate z position
            pkdata(i,16)=widthx ;
            pkdata(i,17)=widthy; 
        % end
      end
    end
end

guidata(gcbo,handles) ;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in advanced.
function advanced_Callback(hObject, eventdata, handles)

detoptions=get(handles.output,'userdata');
options7=detoptions.widthgauss;
options8=detoptions.widthimagefit;
options18=detoptions.pixels;

prompt = {'Width of gaussian correlation function','Width of the image to be fit','Maximum size allowed'};
num_lines= 1;
dlg_title = 'Advanced detection parameters';
def = {num2str(options7),num2str(options8),num2str(options18)}; % default values
answer  = inputdlg(prompt,dlg_title,num_lines,def);
exit=size(answer);
if exit(1) == 0;
   return; 
end
detoptions=get(handles.output,'userdata');
detoptions.widthgauss=str2num(answer{1});
detoptions.widthimagefit=str2num(answer{2});
detoptions.pixels=str2num(answer{3});
set(handles.output,'userdata',detoptions);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)

frames=get(handles.text8,'value');
slidervalue=get(hObject,'Value');
minvalue=get(hObject,'Min');
maxvalue=get(hObject,'Max');
prop=slidervalue/(minvalue+maxvalue);
frame=round(prop*frames);
set(handles.loop,'value',frame);

showimage(handles);

guidata(hObject, handles);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
    
slidervalue=get(hObject,'Value');
minvalue=get(hObject,'Min');
maxvalue=get(hObject,'Max');
prop=slidervalue/(minvalue+maxvalue);
set(handles.text11,'value',prop);

showimage(handles);
guidata(hObject, handles);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in loadfile.
function loadfile_Callback(hObject, eventdata, handles)

% carga files y loop general 
dialog_title=['Select data folder'];
directory_name = uigetdir(cd,dialog_title);
if directory_name==0
    return
end
cd(directory_name)

%choose data
d = dir('*t*');
st = {d.name};
if isempty(st)==1
   msgbox(['No files!!'],'Select files','error')
   return
end
[listafiles,v] = listdlg('PromptString','Select files:','SelectionMode','multiple','ListString',st);
if v==0
   return
end

[f,ultimo]=size(listafiles);
cont=1;

% primera movie
file=st{listafiles(cont)};
[namefile,rem]=strtok(st{listafiles(cont)},'.');
set(handles.filename,'string',file);
warning off all
[ImagePar,Image] = stkdataread(file);
[options]=readdetectionoptions; % default: file detecoptions.mat
stackmin=(min(min(min(Image(1).data))));
stackmax=(max(max(max(Image(1).data))));

set(handles.finalframe,'string',num2str(ImagePar.frames));

%valfactor=round(1000/stackmax*0.5);
set(handles.factor,'string',num2str(1));

% creates file .mat with detection/cutoffs for calibrationgui.m
%detoptions.output=options(1);
%detoptions.minchi=options(2);
%detoptions.mindchi=options(3);
%detoptions.minparvar=options(4);
%detoptions.loops=options(5);
%detoptions.lamba=options(6);
%detoptions.widthgauss=options(7);
%detoptions.widthimagefit=options(8);
%detoptions.threshold=str2num(get (handles.thresh,'string')); % threshold
%detoptions.fit=options(10);
%detoptions.confchi=options(11);
%detoptions.confexp=options(12);
%detoptions.confF=options(13);
%detoptions.bleach=options(14);       
%detoptions.difProb=options(15);
%detoptions.concentr=options(16);
%detoptions.recover=options(17);
%detoptions.pixels=options(18);
%detoptions.cutoff1=cutoffs(1);
%detoptions.cutoff2=str2num(get (handles.maxinten,'string')); % max intensity
%detoptions.cutoff3=cutoffs(3);
% creates file .mat with detection/cutoffs for calibrationgui.m
detoptions.minchi=options(1);
detoptions.mindchi=options(2);
detoptions.minparvar=options(3);
detoptions.loops=options(4);
detoptions.lamba=options(5);
detoptions.pixels=options(6);

detoptions.widthgauss=options(7);
detoptions.widthimagefit=options(8);
detoptions.threshold=str2num(get (handles.thresh,'string')); % threshold

detoptions.confchi=options(10);
detoptions.confexp=options(11);
detoptions.interror=options(12);
detoptions.maxintens=options(13);    

detoptions.minintens=options(14);
detoptions.persistance=options(15);
detoptions.Dini=options(16);

if size(options,1) >16
    detoptions.till=options(17); %handles.till;
    detoptions.szpx=options(18); %handles.szpx;
    filedefnames=get(handles.filedefin,'userdata');
    detoptions.NA = str2num(filedefnames{3}); %numerical aperture
    detoptions.lambda = str2num(filedefnames{4}); %wavelenght
else
    detoptions.till=50;
    detoptions.szpx=160;
    detoptions.NA = 1.45; %numerical aperture
    detoptions.lambda = 600; %wavelenght
end

%detoptions.typefile=typefile; %.spe or .stk
detoptions.image=Image; % datamatrix movie
detoptions.imagepar=ImagePar; % image parameters
set(handles.thresh,'String',num2str(detoptions.threshold));
if isfield(detoptions,'cutoff2')
    set(handles.maxinten,'String',num2str(detoptions.cutoff2));
else
    set(handles.maxinten,'String',num2str(1000000));
end
set(handles.output,'userdata',detoptions);
set(handles.loop,'value',1); %first frame
set(handles.text8,'value',ImagePar.frames);   %last frame
set(handles.loadfile,'userdata',st{listafiles})   %files

showimage(handles,1)

guidata(gcbo,handles) ;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes during object creation, after setting all properties.
function thresh_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes during object creation, after setting all properties.
function maxinten_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes during object creation, after setting all properties.
function width_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes during object creation, after setting all properties.
function skip_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes during object creation, after setting all properties.
function factor_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function mininten_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function firstframe_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function finalframe_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function deltaz_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function slider1_CreateFcn(hObject, eventdata, handles)
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function slider2_CreateFcn(hObject, eventdata, handles)
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function thresh_Callback(hObject, eventdata, handles)
handles.threshold=get(hObject,'String');
guidata(hObject, handles);

function maxinten_Callback(hObject, eventdata, handles)
handles.maxintensity=get(hObject,'String');
guidata(hObject, handles);

function skip_Callback(hObject, eventdata, handles)
handles.skipframes=get(hObject,'String');
guidata(hObject, handles);

function factor_Callback(hObject, eventdata, handles)
handles.valfactor=str2num(get(hObject,'String'));
guidata(hObject, handles);

function mininten_Callback(hObject, eventdata, handles)
guidata(hObject, handles);

function firstframe_Callback(hObject, eventdata, handles)
guidata(hObject, handles);

function finalframe_Callback(hObject, eventdata, handles)
guidata(hObject, handles);

function deltaz_Callback(hObject, eventdata, handles)
guidata(hObject, handles);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
