function colorshiftcorrection




% dialog box to enter recognition criteria for images
prompt = {'Pixel size (nm):','PALM pixel size (nm):'};
num_lines= 1;
dlg_title = 'Correction of multiple detections';
def = {'107','10'};
answer  = inputdlg(prompt,dlg_title,num_lines,def);
exit=size(answer);
if exit(1) == 0;
    return;
end
px_mu=str2num(answer{1})/1000;
dx=str2num(answer{2})/1000;

%files
d=dir('*.mat*'); % .stk files
st={d.name};
if isempty(st)==1
    msgbox(['No files!!'],'','error');
    return
end

%choose data
[listafiles,v] = listdlg('PromptString','Select files:','SelectionMode','multiple','ListString',st);
if v==0
     return
end



for nromovie=1:size(listafiles,2)
    matfile=st{listafiles(nromovie)} ;
   disp=['Correction of stage drift'];
   disp(' ');
    [filename,rem]=strtok(matfile,'.');
        % name second image
    d=dir(['*',ident,'*']); %  files
    st={d.name} ;
    for j=1:size(st,2);
        k = findstr(st{j},firststr);
        if k>0      
            file2=st{j};
            if isempty(file2)==0
                control=1;  
            end
        end
    end
    if control==0
       % disp('Second image not found')
        %not found: enter second image manually
        [file2,path] = uigetfile('*.*','Choose second image file');
        if file2==0
            return
        end
    end
    [namefile2,rem]=strtok(file2,'.'); %sin extension

    [x1,y1, fr1, alpha1, radius1,ffname1,filename1]=PALMdata(matfile,px_mu);
    [x2,y2, fr2, alpha2, radius2,ffname2,filename2]=PALMdata(file2,px_mu);
    
    if dx>0
        x2=x2/dx;
        y2=y2/dx;
    end

    
    matrice_results=colorshift(x1,y1,x2,y2,px_mu,dx);
    
    currentdir=cd;
    k = strfind(currentdir, 'driftcorrected');
    if isempty(k)==1
        if isdir('driftcorrected'); else mkdir('driftcorrected'); end
        cd('driftcorrected')  
    end
    
    % save new data
    if isempty(matrice_results)==0
        auxy= matrice_results(2,:);
        auxx= matrice_results(3,:);  
        matrice_results(3,:)=auxy/px_mu; %reconversion
        matrice_results(2,:)=auxx/px_mu;
        
        xdim=ceil(max(matrice_results(2,:)));
        ydim=ceil(max(matrice_results(3,:)));
        
        %correction coordinates!!
        % att: �m!
        minx1=min(handles.x)/px_mu;
        miny1=min(handles.y)/px_mu;
        maxx1=max(handles.x)/px_mu;
        maxy1=max(handles.y)/px_mu;
        
        indexneg=find(matrice_results(2,:)<minx1);
        if isempty(indexneg)==0
            matrice_results(:,indexneg)=NaN;
        end
        indexneg=find(matrice_results(3,:)<miny1);
        if isempty(indexneg)==0
            matrice_results(:,indexneg)=NaN;
        end
        indexextra=find(matrice_results(3,:)>maxx1);
        if isempty(indexextra)==0
            matrice_results(:,indexextra)=NaN;
        end
        indexextra=find(matrice_results(2,:)>maxy1);
        if isempty(indexextra)==0
            matrice_results(:,indexextra)=NaN;
        end
                
        % false points for size
        last=size(matrice_results,2);
        aux= [matrice_results(1,last) miny1 minx1  matrice_results(4,last)  matrice_results(5,last)];
        matrice_results=[matrice_results, aux'];
        aux=[matrice_results(1,last) maxy1 maxx1  matrice_results(4,last)  matrice_results(5,last)];
        matrice_results=[matrice_results, aux'];
        
        savename=[namefile,'.mat'];
        savename2=[namefile2,'.mat'];
        save(savename2, 'matrice_results'); % second image, corrected for color drift
        clear x y alpha fr radius matrice_results
    end 
    
end

cd(currentdir)


   
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [matrice_results]=colorshift(data.x,data.y,data2.x,data2.y,px_mu,dx)

% MODIF!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

xdim=ceil(max(data.x));
ydim=ceil(max(data.y));

showframe(handles,ydim,xdim,[],data2);  
figure
imshow(zeros(xdim,ydim),'InitialMagnification','fit');
hold on
plot(data2.x,data2.y,'.','MarkerSize',2,'Color','r'); 

set(handles.textzoom,'string','Please select the region to zoom')

% ROI
[areaselect,xi,yi]=roipolyold;    %seleccion ROI
control=0; 

%data en ROI
if isempty(data2)==0        
        aux = find(inpolygon( handles.x, handles.y,xi,yi) );
        newpoints(:,1)= handles.x(aux);
        newpoints(:,2)= handles.y(aux);
        aux = find(inpolygon( data2.x, data2.y,xi,yi)) ;
        newpoints2(:,1)= data2.x(aux);
        newpoints2(:,2)= data2.y(aux);
        
        if isempty(newpoints)==0
            control=1;
        end
end

set(handles.textzoom,'string',[' '])

if control>0
        % define extremos con las pos min y max de las traj
        minposx=ceil(min(newpoints(:,1)));
        minposy=ceil(min(newpoints(:,2)));
        maxposx=floor(max(newpoints(:,1)));
        maxposy=floor(max(newpoints(:,2)));
        dimx=maxposx-minposx+1;
        dimy=maxposy-minposy+1;  
        
        % correccion coordenadas
        newpoints(:,1)= newpoints(:,1)-minposx+1;
        newpoints(:,2)= newpoints(:,2)-minposy+1;  
        newpoints2(:,1)= newpoints2(:,1)-minposx+1;
        newpoints2(:,2)= newpoints2(:,2)-minposy+1;  

        varargin{1}=namefile; %
        varargin{2}=dimy; %inverted!
        varargin{3}=dimx;
        varargin{4}=newpoints;
        varargin{5}=newpoints2; 
        
        % ventana ROI
        varargout=ROIshiftcorrection(varargin);
        uiwait;    
        
        aux=['auxiliar.mat'];    
        
        if length(dir(aux))>0
            det=load(aux);
            detopt = struct2cell(det);
            % result: shift    
            shift=detopt{1};
            
            if isempty(shift)==0
                data2.x=data2.x+shift(1); 
                data2.y=data2.y+shift(2);
            end
            
            matrice_results(1,:)=data2.fr;
            matrice_results(2,:)= data2.x; 
            matrice_results(3,:)= data2.y;
            matrice_results(4,:)=data2.alpha;
            matrice_results(5,:)=data2.radius;  

        end % dir aux  
else  % control
    msgbox('Error','No data files','error')
end  % control

figure
imshow(zeros(xdim,ydim),'InitialMagnification','fit');
hold on


% plot positions
    plot(data2.x,data2.y,'.','MarkerSize',2,'Color','r'); 
    hold on
    plot(data.x,data.y,'.','MarkerSize',2,'Color','y');

clear data2



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
