function corrpeak=correctdetections2(matfile,dist,minintens)

validfile = 0
S=load(matfile) ;
corrpeak=[];

if isfield(S,'matrice_results')
            aux = S.matrice_results;
            clear S;
            peak=[aux(1,:)' aux(3,:)' aux(2,:)'  aux(4,:)' aux(5,:)'*2 ];    
            validfile = 1;
else
            %validfile = 0;
            disp('Invalid file!');
            return
end

if validfile==0
    return
end

% group peaks same molecule
nSeq=max(peak(:,1));
peak=[peak zeros(size(peak,1),1)]; %last column: number of individual mol
waitbarhandle=waitbar( 0,'Please wait...','Name',['Selecting detections of the same molecule in ',matfile]) ;
    
count=1;
forbnumber=[];
corrpeak=[];    
auxpeak=[];    
colmol=size(peak,2);

for Iseq=1:max(peak(:,1))-1 %loop frames
   % indexpresent=find(peak(:,1)==Iseq);
    presentpeaks = peak(find(peak(:,1)==Iseq),:);
    indexnext=find(peak(:,1)==Iseq+1);   
    nextpeaks = peak(indexnext,:);
    if exist('waitbarhandle')
        waitbar(Iseq/max(peak(:,1)),waitbarhandle,['Frame # ',num2str(Iseq)]);
    end
        
        for i=1:size(presentpeaks,1)
            if presentpeaks(i,colmol)>0 %mol already detected
                numbermol=presentpeaks(i,colmol);
            else
                numbermol=count;
                count=count+1;
            end 
            candidatex=find(nextpeaks(:,2)>presentpeaks(i,2)-dist & nextpeaks(:,2)<presentpeaks(i,2)+dist);
            aux1=nextpeaks(candidatex,:);
            candidate=find(aux1(:,3)>presentpeaks(i,3)-dist & aux1(:,3)<presentpeaks(i,3)+dist);
            
            if isempty(candidate)==0     % there is a candidate
                cand=candidate(1);
               if aux1(cand,colmol)==0  % candidate not selected before 
                    realdist=sqrt((presentpeaks(i,2)-aux1(cand,2))^2+(presentpeaks(i,3)-aux1(cand,3))^2);
                    if realdist<dist   % distance ok!
                        peak(indexnext(candidatex(cand)),colmol)=numbermol; % number mol
                    end % control distance    
                end % not selected before
            end % candidate exists
        end % loop present peaks
        
end   % loop while   

if exist('waitbarhandle')
    close(waitbarhandle);
end

%disp('corr peaks')
%disp(peak)

% single detections
indexzero=find(peak(:,colmol)==0);
corrpeak=peak(indexzero,:);

% mean of multiple detections
waitbarhandle=waitbar( 0,'Please wait...','Name',['Correcting detections in ',matfile]) ;

for t=1:max(peak(:,colmol))
    if exist('waitbarhandle')
        waitbar(t/max(peak(:,colmol)),waitbarhandle,['Molecule # ',num2str(t)]);
    end

    index=find(peak(:,colmol)==t);
    if isempty(index)==0
        indexintens=find(peak(index(:),4)>minintens);
        if isempty(indexintens)==0
            meanx=mean(peak(index(indexintens),2));
            meany=mean(peak(index(indexintens),3));
            meanint=mean(peak(index(indexintens),4));
            meanrad=mean(peak(index(indexintens),5)) ;
            corrpeak=[corrpeak; peak(index(1),1) meanx meany  meanint meanrad peak(index(1),colmol)];
        end
    end
end
corrpeak=sortrows(corrpeak,1);
%disp(size(peak))
%disp(size(corrpeak))

save('peak.txt','peak','-ascii')
save('corrpeak.txt','corrpeak','-ascii')

if exist('waitbarhandle')
    close(waitbarhandle);
end

disp('Done')
disp(' ')

plotcontrol=0;
if plotcontrol
          figure
       Im=ones(ceil(max(peak(:,3))),ceil(max(peak(:,2)))); %!!!!!!!!!!!!!!!!!!
       imshow(Im,'InitialMagnification','fit');
       hold on
       plot(peak(:,2),peak(:,3),'o','MarkerSize',5,'Color','b');
       hold on
       plot(corrpeak(:,2),corrpeak(:,3),'x','MarkerSize',5,'Color','r');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    
    
    