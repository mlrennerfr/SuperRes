function corrpeak=correctdetections3(matfile,blinkdist,a,blinktime)

Dini=0.0005; %!!!!!!!!!!!!!!!!!!!!!
Te=50; % mock till

validfile = 0;
S=load(matfile) ;
corrpeak=[];

if isfield(S,'matrice_results')
            aux = S.matrice_results;
            clear S;
            if size(aux,1)>7
                peak=[aux(1,:)' aux(3,:)' aux(2,:)'  aux(4,:)' aux(5,:)'*2 aux(7,:)' aux(6,:)' aux(8,:)' aux(9,:)' aux(10,:)' aux(11,:)'];
                validfile = 1;
            else
                peak=[aux(1,:)' aux(3,:)' aux(2,:)'  aux(4,:)' aux(5,:)'*2 aux(7,:)' aux(6,:)'];
                validfile = 1;
            end
else
            %validfile = 0;
            disp('Invalid file!');
            return
end

if validfile==0
    return
end

% group peaks same molecule

%corrpeak = trackcorrdet(peak, Dini, Te,a,blinkdist,blinktime);
corrpeak=buildTrackscorrdet(peak, Dini, Te,a,blinkdist,blinktime);
%reconnectedfile=buildTrackscorrdet(pk, szpx,till) %att   variables!!!!!!!!!!!

disp('Done')
disp(' ')

plotcontrol=0;
if plotcontrol
          figure
       Im=ones(ceil(max(peak(:,3))),ceil(max(peak(:,2)))); %!!!!!!!!!!!!!!!!!!
       imshow(Im,'InitialMagnification','fit');
       hold on
       plot(peak(:,2),peak(:,3),'o','MarkerSize',5,'Color','b');
       hold on
       plot(corrpeak(:,2),corrpeak(:,3),'x','MarkerSize',5,'Color','r');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    
    
    