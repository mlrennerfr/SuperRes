function add3Dpk(handles)

    seuil_alpha = str2num(get(handles.alphavalue,'String'));
    wn = str2num(get(handles.windsize, 'String'));
    szpx=str2num(get(handles.pixel,'string'));

    currentdir=cd;

    %ask for calibration curve
    [file,path] = uigetfile('*calibration3D.mat','Load calibration curve');
    if isempty(file)==1
        return
    end
    cd(path)
    load(file,'-mat') %fitresult

%files
cd(currentdir)
d=dir('*tif*'); % .stk files
st={d.name};
if isempty(st)==1
  %  d=dir('*nd2*'); % nikon files
  %  st={d.name};
  %  if isempty(st)==1
        msgbox(['No files!!'],'','error');
        return
%    end
end

%choose data
[files,v] = listdlg('PromptString','Select files:','SelectionMode','multiple','ListString',st);
if v==0
     return
end

[f,ultimo]=size(files);

for i=1:ultimo
      name_stk=st{files(i)};
      [namefile,rem]=strtok(name_stk,'.');
      info=imfinfo(name_stk);
      Nb_image_ds_stack =length(info);

      
      [ImagePar,Image] = stkdataread(name_stk);
      cd([currentdir,'\driftcorrected\pk'])
      if isdir(['pk3']); else; mkdir(['pk3']); end %VOIR

      namepk=[namefile,'.pk']
      pk=load(namepk);   
      
      disp('Adding z coordinate...')  
      waitbarhandle=waitbar( 0,'Please wait...','Name','Adding z coordinate') ;  
      
      [datawidth,pk]=go3D(pk,Image,Nb_image_ds_stack,fitresult,wn,seuil_alpha,szpx,waitbarhandle);
         clear Image ImagePar
         close(waitbarhandle);
         
         % prepare file for visp
         pkvisp=[pk(:,2) pk(:,3) pk(:,8) pk(:,5) pk(:,1)];         
         %[x y z alpha fr];
         
         save(['pk3\',namefile, '.3d'], 'pkvisp','-ascii');
         save(['pk3\',namefile, '-datawidth.txt'], 'datawidth','-ascii');
       %  if isempty(totalpk)==0
       %      index=find(totalpk(:,17)<1000 & totalpk(:,17)~=NaN);
         save (['pk3\',namefile,'.pk3'], 'pk','-ascii');
       %      save (['pk3\',namefile,'.cal'], 'datawidth','-ascii');
     %    end
     cd(currentdir)
end %loop files

