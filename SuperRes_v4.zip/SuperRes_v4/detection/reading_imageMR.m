function [NbrOfFoldersToAnalyse,ListOfFoldersToAnalyse,NbrOfImages, NbreOfImagesperFolder, images_name]=reading_imageMR

logical=1;
ListOfFoldersToAnalyse={};
NbreOfImagesperFolder={};

currentdir=cd;
dialog_title=['Select data folder (with .tif files)'];
path = uigetdir(cd,dialog_title);
if path==0
    return
end
NbrOfFoldersToAnalyse=1;
%folders{1}=path;
NbrOfImages=0;
files={};
fichier={};

while logical % allows entering data from different folders
    
    % dialog box to select files
    d=dir('*.tif*');
    st = {d.name};
    [listafiles,v] = listdlg('PromptString','Select files:','SelectionMode','multiple','ListString',st);
    if v==0
        return
    end
    
    NbrOfImages=NbrOfImages+size(listafiles,2);
    
    % loop over files
    for cont=1:size(listafiles,2)
        file=[st{listafiles(cont)}];
        
       % structure=struct('file', {files_currentfolder});
        structure=struct('file', file);
        fichier=[fichier, structure];
        files=[files, fichier{ind}];
    
        % dialog box to enter new data from another folder
        qstring=['more data folders?'];
        button = questdlg(qstring); 
        if strcmp(button,'Yes')
            logical=1;
            dialog_title=['Select data folder (with .tif files)'];
            path = uigetdir(cd,dialog_title);
            if path==0
                return
            end
            NbrOfFoldersToAnalyse=NbrOfFoldersToAnalyse+1;
            % folders{NbrOfFoldersToAnalyse}=path;
        else
            break
            logical=0
        end
    end
end % while

images_name=files;

%%%%%%%%%%%%
